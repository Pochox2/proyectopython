from setuptools import setup

setup(
        
    name="paquete1",
    version="1.0",
    description="Paquete para un ecommerce",
    author="InsuaDev",
    author_email="leooinsua79@gmail.com",

    packages=["paquete1"]

)